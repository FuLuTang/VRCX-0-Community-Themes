# Jirai Kei · Windose Dark

Pink Win98-style window chrome over dark purple jirai-kei panels, with pixel controls, lace edges, hearts, photo-corner charms and optional stepped motion. Created by **FuLuTang**.

## Local release candidate — not cleared for public distribution

This package preserves the currently approved artwork. It includes NSO/Steam/Fandom-derived artwork whose public redistribution permission has **not** been established in the author's local records. Attribution alone does not grant permission. Do not publish this candidate as a fully GPL-cleared asset bundle. Permission or approved replacement artwork is needed before an upstream submission.

## Features

- Pink pixel window title bars and frames, including player/entity details and the AI assistant.
- Dark panels, pixel buttons and form controls, calendars, menus, tooltips and status indicators.
- Photo-corner bandages and the author's edited pixel hearts; envelope/title-bar icons and empty-state cat artwork.
- Pixel fonts, decorative lace and stepped hover/motion effects. Theme-owned motion honors `prefers-reduced-motion` and the application's reduced-effects mode.
- Self-contained CSS with embedded fonts and images; no remote image or font requests. Based on dark mode; built-in accent color control is disabled.

## Loading and recovery

In a VRCX-0 **Theme Dev Kit** build, open the local theme preview tools and select this folder, not the repository root. Reload the local preview after replacing the stylesheet. Use **Stop preview** to restore the previously selected appearance.

This candidate does not change application code or data. Close/cancel/recovery controls are not intentionally hidden. Some selectors depend on application DOM/classes and may need updates when VRCX-0 changes.

## Verification and limitations

The current CSS was checked in a Windows/WebView2 custom **VRCX-0-jirai** build, including player details and the previously clipped AI assistant title bar. Synthetic dialog geometry tests and frozen page style regressions also passed before packaging. These checks are **not** a claim of full compatibility with upstream VRCX-0 **2.33.0**, the latest release checked during preparation.

`testedWith` remains `0.0.0-unverified` until an exact upstream version is tested. The preview image is a **synthetic layout with fictional data**, not a screenshot of real friends or a claim of upstream Windows certification.

## Licenses and asset provenance

- Original theme CSS and original decorations: intended for GPL-3.0-only community-theme distribution, subject to clearing the separately identified third-party artwork.
- Pixel glyphs derived from Lucide/Feather: ISC/MIT; full notices are retained at the beginning of `theme.css`.
- Embedded Fusion Pixel and Silkscreen font subsets: SIL Open Font License 1.1; full notices are retained at the beginning of `theme.css`.
- NSO/NEEDY STREAMER OVERLOAD-derived cats, character/game art and related Steam/Fandom-hosted imagery: copyrights remain with their respective rights holders. Fandom/Steam hosting is not a redistribution license. These assets were selected for the author's personal theme; public licensing remains unresolved.

The standalone stylesheet is assembled from the author's modular source and formatted for review, retaining rule order and embedded asset data. Upstream maintainers must confirm that this satisfies their prohibition on generated CSS before it is submitted.
